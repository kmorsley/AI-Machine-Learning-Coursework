import pandas as pd
import matplotlib.pyplot as plt
from pathlib import Path


def save_pie_chart(counts, path):
	fig, ax = plt.subplots()
	counts.plot.pie(ax=ax, autopct='%1.1f%%', startangle=90)
	ax.set_ylabel('')
	ax.set_title('Performance Category Distribution')
	fig.tight_layout()
	fig.savefig(path)
	plt.close(fig)


def main():
	base = Path(__file__).parent
	data_path = base / 'student_performance.csv'

	# 1. Load dataset
	df = pd.read_csv(data_path)

	# 2. Display first five rows
	print('First five rows:')
	print(df.head())

	# 3. Calculate summary statistics
	cols = ['Study_Hours', 'Attendance_Pct', 'Exam_Score']
	summary_df = df[cols].agg(['mean', 'median', 'min', 'max', 'std']).T
	print('\nSummary statistics:')
	print(summary_df)

	# 4. Count students in each Performance_Category
	perf_counts = df['Performance_Category'].value_counts()
	print('\nPerformance category counts:')
	print(perf_counts)

	# 5. Create and save pie chart
	pie_path = base / 'performance_category_pie.png'
	save_pie_chart(perf_counts, pie_path)

	# 6 & 7. Save summary statistics and counts as CSV
	summary_path = base / 'summary_statistics.csv'
	counts_path = base / 'performance_category_counts.csv'
	summary_df.to_csv(summary_path)
	perf_counts.rename_axis('Performance_Category').reset_index(name='Count').to_csv(counts_path, index=False)

	print(f"\nSaved: {summary_path.name}, {counts_path.name}, {pie_path.name}")


if __name__ == '__main__':
	main()

